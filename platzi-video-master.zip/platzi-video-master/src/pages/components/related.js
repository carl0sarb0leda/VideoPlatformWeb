import React from 'react';
// import logo from '../../../images/logo.png';
import './related.css';

function Related(props) {
  return (
    <div className="Related">
      <img src="images/logo.png" width={250}/>
    </div>
  )
}

export default Related;
